//
//  get_btilde.h
//  
//
//  Created by Benjamin Foster on 10/20/15.
//
//

#ifndef ____get_btilde__
#define ____get_btilde__

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "typeutil.h"

double get_btilde(double delta, double b, double sigma_x, double p, double q, double T);

#endif /* defined(____get_btilde__) */
